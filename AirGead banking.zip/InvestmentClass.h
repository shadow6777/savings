/* Ronald Spires
CS-210
03/31/2021 */
/// InvestmentClass.h
#include<iostream>
#include<cstring>
#include<math.h> /* pow */
#include<iomanip> //for setprecision and setw
using namespace std;

class InvestmentClass { //create class with variables
private:
	double m_intInvAm;
	double m_mnthDep;
	double m_annInt;
	int m_numYrs;

public:
	double getIntInvAm();     //accessors
	void setIntInvAm(double t_amt);
	double getMnthDep();
	void setMnthDep(double t_dep);
	double getAnnInt();
	void setAnnInt(double t_ann);
	int getNumYrs();
	void setNumYrs(int t_yrs);
	void balNoDep();          //balance without additional deposit
	void balWDep();          //balance with additional deposit
};
