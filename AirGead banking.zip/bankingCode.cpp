/* Ronald Spires
CS-210
03/31/2021 */
///////////// main.cpp
#include<iostream>
#include<cstring>
#include<math.h> /* pow */
#include<iomanip> //for setprecision and setw

# include "InvestmentClass.h"
using namespace std;

int main() {
	double intInvAm = 0.0; //Initial Investment Amount
	double mnthDep = 0;    // Monthly Deposit
	double annInt = 0.0;   //Annual Amount
	int numYrs = 0;       //Number of years
	int userInput = 1;
	while (userInput == 1) { //loop program
	// display menu
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "~~ Initial Investment Amount: " << "                       ~~~~~~~~~~~~" << endl;
		cout << "~~ Monthly Deposit: " << "                                 ~~~~~~~~~~~~" << endl;
		cout << "~~ Annual Interest: " << "                                 ~~~~~~~~~~~~" << endl;
		cout << "~~ Number of years: " << "                                 ~~~~~~~~~~~~" << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << endl;
		system("pause");

		//here create an object to class
		InvestmentClass invObj;
		cout << "=================================================================" << endl;
		//prompt for input on variables and check if they are 1 or above (positive)
		cout << "Enter an amount for Initial investment: ";
		cin >> intInvAm;

		//here call setter

		while (intInvAm < 1) {//here in if condition instead if IntInvAm call getter
			cout << "Please enter a positive number." << endl;
			cout << "Enter an amount for initial investment: ";
			cin >> intInvAm;
		}
		invObj.setIntInvAm(intInvAm);//pass IntInvAm read value as argument

		cout << "Enter an amount for Monthly Deposit: ";
		cin >> mnthDep;
		while (mnthDep < 1) {
			cout << "Please enter a positive number." << endl;
			cout << "Enter an amount for Monthly Deposit: ";
			cin >> mnthDep;
		}
		invObj.setMnthDep(mnthDep);

		cout << "Enter an amount for Annual Interest: ";
		cin >> annInt;
		while (annInt < 1) {
			cout << "Please enter a positive number of annual interest." << endl;
			cout << "Enter an amount for Annual Interest: ";
			cin >> annInt;
		}
		invObj.setAnnInt(annInt);

		cout << "Enter a Number of years: ";
		cin >> numYrs;
		while (numYrs < 1) {
			cout << "Please enter a positive number of years!" << endl;
			cout << "Enter a Number of years: ";
			cin >> numYrs;
		}
		invObj.setNumYrs(numYrs);

		cout << "=================================================================" << endl;
		//redisplay menu with users input.
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "~~ Initial Investment Amount: " << intInvAm << "                      ~~~~~~~~~~~~" << endl;
		cout << "~~ Monthly Deposit: " << mnthDep << "                               ~~~~~~~~~~~~" << endl;
		cout << "~~ Annual Interest: " << annInt << "                                ~~~~~~~~~~~~" << endl;
		cout << "~~ Number of years: " << numYrs << "                                ~~~~~~~~~~~~" << endl;
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		system("pause");
		invObj.balNoDep();
		invObj.balWDep();
		cout << "Enter new info(1), or Quit program(0)" << endl;
		cin >> userInput; //end of loop
	}
}