/* Ronald Spires
CS-210
03/31/2021 */
////////// InvestmentClass.cpp

#include<iostream>
#include<cstring>
#include<math.h> /* pow */
#include<iomanip> //for setprecision and setw

# include "InvestmentClass.h"
using namespace std;


double InvestmentClass::getIntInvAm()//start the member function body
{
	//getters usually returns the variable values so simply a return statement is done
	return m_intInvAm;
}

void InvestmentClass::setIntInvAm(double t_amt)//sets value or assigns value to InvInvAm variabe
{
	//the value to set is amt, the parameter/argument
	m_intInvAm = t_amt;
}

double InvestmentClass::getMnthDep()
{
	return m_mnthDep;
}

void InvestmentClass::setMnthDep(double t_dep)
{
	m_mnthDep = t_dep;
}

double InvestmentClass::getAnnInt()
{
	return m_annInt;
}

void InvestmentClass::setAnnInt(double t_ann)
{
	m_annInt = t_ann;
}

int InvestmentClass::getNumYrs()
{
	return m_numYrs;
}

void InvestmentClass::setNumYrs(int t_yrs)
{
	m_numYrs = t_yrs;
}

void InvestmentClass::balNoDep() { //class for balance with no deposits
	double LastBalance = m_intInvAm;
	double LastInterest = 0;
	cout << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "Balance and Interest without additional monthly deposits" << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "Year" << "       Year end balance        " << "Year end earned interest" << endl;
	for (int i = 1; i <= m_numYrs; i++) {
		LastInterest = (LastBalance * (1 + m_annInt / 100) - LastBalance); //formula to find last interest
		LastBalance = LastBalance + LastInterest;
		cout << setw(2) << i << "      ";
		cout << fixed << setw(11) << setprecision(2); //setting precision to show decimal places
		cout << LastBalance << "                 ";
		cout << fixed << setw(11) << setprecision(2);
		cout << LastInterest << endl;

	}
}

void InvestmentClass::balWDep()
{
	double LastBalance = m_intInvAm;
	double LastInterest = 0;
	double endOfyearValue = m_intInvAm;
	cout << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "Balance and Interest with additional monthly deposits" << endl;
	cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	cout << "Year" << "       Year end balance        " << "Year end earned interest" << endl;
	for (int i = 1; i <= m_numYrs; i++) {
		//double bal1 = LastBalance;
		double yearlyInt = 0;
		for (int j = 0; j < 12; ++j)
		{
			LastInterest += m_mnthDep; //formula to find last interest
			endOfyearValue = endOfyearValue + m_mnthDep;
			yearlyInt += LastBalance * m_annInt / 1200;
			LastBalance += LastBalance * m_annInt / 1200;
			endOfyearValue = endOfyearValue + (endOfyearValue) * ((m_annInt / 100) / 12);
		}
		//Yearly value


		//LastInterest = LastBalance - bal1;
		//cout << setw(2) << i << "      " << LastBalance << "                  " << yearlyInt << endl;
		cout << setw(2) << i << "      " << endOfyearValue << "                  " << yearlyInt << endl;

	}
}